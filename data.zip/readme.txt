graph_cb.txt: 

first column: user id1
second column: user id2
third column: the day when user1 follow user 2,  please notice that 1 means the follow link of user1 to user2 is the original link in the network. 2,3,4... means one specific day.


interaction_list_all.txt:

first column: user id1
second column: user id2
third column:  user1 @ user2 one time, please notice that one pair of two users may be duplicated in the dataset. The duplicated number means the @ times.
